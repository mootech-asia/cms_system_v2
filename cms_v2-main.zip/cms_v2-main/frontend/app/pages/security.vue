<script setup lang="ts">
import { ref } from 'vue';
const root = ref<HTMLElement | null>(null);
useMemberPage(root);
</script>

<template>
  <div ref="root" class="min-h-screen bg-[#0f1419]" style="overflow-x: hidden;">
    <MemberHeader />
    <div class="flex bg-[#0f1419] min-h-screen" style="overflow-x: hidden;">
    <aside class="hidden md:block w-64 flex-shrink-0 bg-[#1a2128] border-r border-gray-800 sticky top-0 h-screen overflow-y-auto">
    <nav class="p-4 space-y-2">
    <a class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-gray-300 hover:bg-[#0f1419] hover:text-white" href="/account">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-layout-dashboard w-5 h-5">
    <rect width="7" height="9" x="3" y="3" rx="1">
    </rect>
    <rect width="7" height="5" x="14" y="3" rx="1">
    </rect>
    <rect width="7" height="9" x="14" y="12" rx="1">
    </rect>
    <rect width="7" height="5" x="3" y="16" rx="1">
    </rect>
    </svg>
    <span class="text-sm">Account Overview</span>
    </a>
    <a class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-gray-300 hover:bg-[#0f1419] hover:text-white" href="/deposit">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-down-to-line w-5 h-5">
    <path d="M12 17V3">
    </path>
    <path d="m6 11 6 6 6-6">
    </path>
    <path d="M19 21H5">
    </path>
    </svg>
    <span class="text-sm">Deposit</span>
    </a>
    <a class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-gray-300 hover:bg-[#0f1419] hover:text-white" href="/withdrawal">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-up-from-line w-5 h-5">
    <path d="m18 9-6-6-6 6">
    </path>
    <path d="M12 3v14">
    </path>
    <path d="M5 21h14">
    </path>
    </svg>
    <span class="text-sm">Withdrawal</span>
    </a>
    <a class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-gray-300 hover:bg-[#0f1419] hover:text-white" href="/betting-record">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-history w-5 h-5">
    <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8">
    </path>
    <path d="M3 3v5h5">
    </path>
    <path d="M12 7v5l4 2">
    </path>
    </svg>
    <span class="text-sm">Betting Record</span>
    </a>
    <a class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-gray-300 hover:bg-[#0f1419] hover:text-white" href="/deposit-record">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-file-text w-5 h-5">
    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z">
    </path>
    <path d="M14 2v4a2 2 0 0 0 2 2h4">
    </path>
    <path d="M10 9H8">
    </path>
    <path d="M16 13H8">
    </path>
    <path d="M16 17H8">
    </path>
    </svg>
    <span class="text-sm">Deposit Record</span>
    </a>
    <a class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-gray-300 hover:bg-[#0f1419] hover:text-white" href="/profit-loss">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-trending-up w-5 h-5">
    <polyline points="22 7 13.5 15.5 8.5 10.5 2 17">
    </polyline>
    <polyline points="16 7 22 7 22 13">
    </polyline>
    </svg>
    <span class="text-sm">Profit And Loss</span>
    </a>
    <a class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-gray-300 hover:bg-[#0f1419] hover:text-white" href="/withdrawal-record">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-file-text w-5 h-5">
    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z">
    </path>
    <path d="M14 2v4a2 2 0 0 0 2 2h4">
    </path>
    <path d="M10 9H8">
    </path>
    <path d="M16 13H8">
    </path>
    <path d="M16 17H8">
    </path>
    </svg>
    <span class="text-sm">Withdrawal Record</span>
    </a>
    <a class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-gray-300 hover:bg-[#0f1419] hover:text-white" href="/account-record">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-file-text w-5 h-5">
    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z">
    </path>
    <path d="M14 2v4a2 2 0 0 0 2 2h4">
    </path>
    <path d="M10 9H8">
    </path>
    <path d="M16 13H8">
    </path>
    <path d="M16 17H8">
    </path>
    </svg>
    <span class="text-sm">Account Record</span>
    </a>
    <a class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-gray-300 hover:bg-[#0f1419] hover:text-white" href="/personal-info">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user w-5 h-5">
    <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2">
    </path>
    <circle cx="12" cy="7" r="4">
    </circle>
    </svg>
    <span class="text-sm">Personal Info</span>
    </a>
    <a class="flex items-center gap-3 px-4 py-3 rounded-lg transition-all bg-gradient-to-r from-[#CBE8E4] to-[#98E7D2] text-gray-900 font-semibold" href="/security">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shield w-5 h-5">
    <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z">
    </path>
    </svg>
    <span class="text-sm">Security Center</span>
    </a>
    <button class="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-gray-300 hover:bg-[#0f1419] hover:text-white">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-message-circle w-5 h-5">
    <path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z">
    </path>
    </svg>
    <span class="text-sm">Customer Service</span>
    </button>
    </nav>
    </aside>
    <main class="flex-1 min-w-0 p-4 md:p-8 flex flex-col items-center" style="padding-bottom: 80px;">
    <h1 class="text-white text-3xl mb-8 w-full">Security Center</h1>
    <div class="w-full max-w-4xl">
    <h2 class="text-gray-400 text-sm font-semibold uppercase tracking-wider mb-2">Last login</h2>
    <div class="bg-[#1a2128] border border-gray-800 rounded-lg p-4 mb-6">
    <div class="flex items-center justify-between py-2">
    <span class="text-white text-sm">Time</span>
    <span class="text-gray-400 text-sm">2026/04/21 13:29:25</span>
    </div>
    <div class="border-t border-gray-700 my-1">
    </div>
    <div class="flex items-center justify-between py-2">
    <span class="text-white text-sm">IP Address</span>
    <span class="text-gray-400 text-sm">125.227.44.193</span>
    </div>
    </div>
    <h2 class="text-gray-400 text-sm font-semibold uppercase tracking-wider mb-2">Security Setting</h2>
    <div class="bg-[#1a2128] border border-gray-800 rounded-lg overflow-hidden">
    <div class="flex items-center justify-between p-4 border-b border-gray-800 hover:bg-[#0f1419] cursor-pointer">
    <div class="flex items-center gap-3">
    <div class="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0" style="background-color: rgba(152, 231, 210, 0.15);">
    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: rgb(152, 231, 210);">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z">
    </path>
    </svg>
    </div>
    <div>
    <div class="text-white text-sm font-semibold">Personal Info</div>
    <div class="text-gray-500 text-xs mt-0.5">Complete your personal profile</div>
    </div>
    </div>
    <span class="text-gray-500 text-sm whitespace-nowrap flex-shrink-0">Not set ›</span>
    </div>
    <div class="flex items-center justify-between p-4 border-b border-gray-800 hover:bg-[#0f1419] cursor-pointer">
    <div class="flex items-center gap-3">
    <div class="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0" style="background-color: rgba(152, 231, 210, 0.15);">
    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: rgb(152, 231, 210);">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2">
    </rect>
    </svg>
    </div>
    <div>
    <div class="text-white text-sm font-semibold">Change Login Password</div>
    <div class="text-gray-500 text-xs mt-0.5">Recommended letter and number combination</div>
    </div>
    </div>
    <span class="text-gray-500 text-sm whitespace-nowrap flex-shrink-0">Not set ›</span>
    </div>
    <div class="flex items-center justify-between p-4 border-b border-gray-800 hover:bg-[#0f1419] cursor-pointer">
    <div class="flex items-center gap-3">
    <div class="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0" style="background-color: rgba(152, 231, 210, 0.15);">
    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: rgb(152, 231, 210);">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z">
    </path>
    </svg>
    </div>
    <div>
    <div class="text-white text-sm font-semibold">Change Transaction Password</div>
    <div class="text-gray-500 text-xs mt-0.5">Set a password to improve the security of fund operations</div>
    </div>
    </div>
    <span class="text-gray-500 text-sm whitespace-nowrap flex-shrink-0">Not set ›</span>
    </div>
    <div class="flex items-center justify-between p-4 border-b border-gray-800 hover:bg-[#0f1419] cursor-pointer">
    <div class="flex items-center gap-3">
    <div class="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0" style="background-color: rgba(152, 231, 210, 0.15);">
    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: rgb(152, 231, 210);">
    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z">
    </path>
    </svg>
    </div>
    <div>
    <div class="text-white text-sm font-semibold">Banking Details</div>
    <div class="text-gray-500 text-xs mt-0.5">Recommended letter and number combination</div>
    </div>
    </div>
    <span class="text-gray-500 text-sm whitespace-nowrap flex-shrink-0">Not set ›</span>
    </div>
    <div class="flex items-center justify-between p-4 hover:bg-[#0f1419] cursor-pointer">
    <div class="flex items-center gap-3">
    <div class="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0" style="background-color: rgba(152, 231, 210, 0.15);">
    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: rgb(152, 231, 210);">
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9">
    </path>
    </svg>
    </div>
    <div>
    <div class="text-white text-sm font-semibold">Logout</div>
    <div class="text-gray-500 text-xs mt-0.5">Logout safely</div>
    </div>
    </div>
    <span class="text-gray-500 text-sm whitespace-nowrap flex-shrink-0">Not set ›</span>
    </div>
    </div>
    </div>
    </main>
    </div>
    <MobileBottomNav />
  </div>
</template>
